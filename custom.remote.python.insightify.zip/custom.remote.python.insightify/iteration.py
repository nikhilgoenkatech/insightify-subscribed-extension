# Time in mins - timeframe after which the extension will gather metric for each of the section as defined below.
COLLECT_CONSUMPTION_DATA=60
COLLECT_FF_DATA=10080

#When to collect the first sample of problem data
COLLECT_PROBLEM_DATA=1
